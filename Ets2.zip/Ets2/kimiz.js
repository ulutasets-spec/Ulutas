function geriDon() {
    window.location.href = "anasayfa.html";
}